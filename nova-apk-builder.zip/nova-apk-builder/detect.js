// تشخیص نسخه AGP / Gradle / JDK از روی خود پروژه (بدون اجرای هیچ کدی)
const fs = require('fs');
const path = require('path');

// حداقل نسخه Gradle لازم برای هر نسخه Android Gradle Plugin (مطابق جدول سازگاری رسمی؛ هر نسخه بالاتر که
// پروژه خودش wrapper داشته باشد همان استفاده می‌شود). نسخه‌های ۹ به بالا کمتر مطمئن هستند.
const AGP_GRADLE = {
  '4.0': '6.1.1', '4.1': '6.5', '4.2': '6.7.1',
  '7.0': '7.0.2', '7.1': '7.2', '7.2': '7.3.3', '7.3': '7.4', '7.4': '7.5',
  '8.0': '8.0', '8.1': '8.0', '8.2': '8.2', '8.3': '8.4', '8.4': '8.6', '8.5': '8.7', '8.6': '8.7',
  '8.7': '8.9', '8.8': '8.10.2', '8.9': '8.11.1', '8.10': '8.11.1', '8.11': '8.13', '8.12': '8.13', '8.13': '8.13',
  '9.0': '9.1.0',
};
const DEFAULT_GRADLE = '8.13';

function cmp(a, b) {
  const A = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const B = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (A[i] || 0) - (B[i] || 0);
    if (d) return d;
  }
  return 0;
}

function gradleForAgp(agp) {
  const m = /^(\d+)\.(\d+)/.exec(agp || '');
  if (!m) return null;
  const key = `${m[1]}.${m[2]}`;
  if (AGP_GRADLE[key]) return AGP_GRADLE[key];
  const keys = Object.keys(AGP_GRADLE).sort(cmp);
  let best = null;
  for (const k of keys) if (cmp(k, key) <= 0) best = k;
  return AGP_GRADLE[best || keys[0]];
}

function walk(root, maxDepth, visit) {
  const queue = [[root, 0]];
  while (queue.length) {
    const [dir, depth] = queue.shift();
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (depth < maxDepth && !['build', '.gradle', 'node_modules', '.git', '.idea'].includes(e.name)) queue.push([p, depth + 1]);
      } else visit(p, e.name);
    }
  }
}

function readText(p) { try { return fs.readFileSync(p, 'utf8'); } catch { return ''; } }

function collectText(projectDir) {
  let text = '';
  walk(projectDir, 2, (p, name) => {
    if (text.length > 2_000_000) return;
    if (/^(build|settings)\.gradle(\.kts)?$/.test(name) || name === 'libs.versions.toml') text += '\n' + readText(p);
  });
  return text.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '$1');
}

function detectAgp(text) {
  const res = [
    /com\.android\.tools\.build:gradle:(\d+\.\d+(?:\.\d+)?)/,
    /["']com\.android\.(?:application|library)["']\s*\)?\s*version\s*\(?\s*["'](\d+\.\d+(?:\.\d+)?)/,
    /^\s*(?:agp|androidGradlePlugin|android-gradle-plugin|androidGradle)\s*=\s*["'](\d+\.\d+(?:\.\d+)?)/im,
  ];
  for (const re of res) {
    const m = re.exec(text);
    if (m) return m[1];
  }
  return null;
}

function detectJavaWanted(text) {
  let max = 0;
  const bump = (n) => { if (n > max && n < 100) max = n; };
  for (const m of text.matchAll(/JavaVersion\.VERSION_(\d+)(?:_(\d+))?/g)) bump(m[1] === '1' && m[2] ? +m[2] : +m[1]);
  for (const m of text.matchAll(/jvmTarget\s*(?:=|\.set\()\s*["'](?:1\.)?(\d+)/g)) bump(+m[1]);
  for (const m of text.matchAll(/JVM_(\d+)/g)) bump(+m[1]);
  for (const m of text.matchAll(/jvmToolchain\s*\(\s*(\d+)/g)) bump(+m[1]);
  for (const m of text.matchAll(/JavaLanguageVersion\.of\(\s*(\d+)/g)) bump(+m[1]);
  return max;
}

function detectCompileSdk(text) {
  let max = 0;
  for (const m of text.matchAll(/compileSdk(?:Version)?\s*[=(]?\s*["']?(?:android-)?(\d{2})\b/g)) max = Math.max(max, +m[1]);
  for (const m of text.matchAll(/compileSdk\s*\{[^}]*?release\(\s*(\d{2})/g)) max = Math.max(max, +m[1]);
  return max || null;
}

function detectWrapper(projectDir) {
  const props = readText(path.join(projectDir, 'gradle', 'wrapper', 'gradle-wrapper.properties'));
  const m = /gradle-(\d+(?:\.\d+){1,2}(?:-(?:rc|milestone)-\d+)?)-(?:bin|all)\.zip/.exec(props);
  return {
    wrapperVer: m ? m[1] : null,
    hasJar: fs.existsSync(path.join(projectDir, 'gradle', 'wrapper', 'gradle-wrapper.jar')),
    hasBat: fs.existsSync(path.join(projectDir, 'gradlew.bat')),
  };
}

function chooseJdk(agp, gradle, javaWanted) {
  let jdk;
  if (gradle && cmp(gradle, '7.3') < 0) jdk = 11;               // Gradle قدیمی روی JDK 17 اجرا نمی‌شود
  else if (gradle && cmp(gradle, '8.0') >= 0) jdk = 17;
  else if (agp) jdk = Number(agp.split('.')[0]) >= 8 ? 17 : 11;
  else jdk = 17;
  if (javaWanted >= 17 && jdk < 17 && (!gradle || cmp(gradle, '7.3') >= 0)) jdk = 17;
  if (javaWanted >= 21 && gradle && cmp(gradle, '8.5') >= 0) jdk = 21;
  return jdk;
}

function detect(projectDir) {
  const text = collectText(projectDir);
  return { agp: detectAgp(text), javaWanted: detectJavaWanted(text), compileSdk: detectCompileSdk(text), ...detectWrapper(projectDir) };
}

function plan(info) {
  const useWrapper = !!(info.wrapperVer && info.hasBat && info.hasJar);
  let gradle, gradleSrc;
  if (info.wrapperVer) { gradle = info.wrapperVer; gradleSrc = useWrapper ? 'project wrapper' : 'wrapper properties'; }
  else if (info.agp) { gradle = gradleForAgp(info.agp); gradleSrc = 'from AGP ' + info.agp; }
  else { gradle = DEFAULT_GRADLE; gradleSrc = 'default'; }
  return { useWrapper, gradle, gradleSrc, jdk: chooseJdk(info.agp, gradle, info.javaWanted) };
}

module.exports = { detect, plan, chooseJdk, gradleForAgp, DEFAULT_GRADLE };
