const { app, BrowserWindow, ipcMain, dialog, shell, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');
const builder = require('./builder');

let win;
let building = false;

// ---- تنظیمات: محل ذخیره ابزارها (مثلا روی درایو D) ----
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), 'utf8')); } catch { return {}; }
}
function writeSettings(s) {
  fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(s, null, 2));
}
const dataRoot = () => readSettings().dataRoot || app.getPath('userData');

// ---- محاسبه حجم پوشه‌ها ----
async function dirSize(p) {
  let total = 0;
  const stack = [p];
  while (stack.length) {
    const d = stack.pop();
    let ents;
    try { ents = await fs.promises.readdir(d, { withFileTypes: true }); } catch { continue; }
    await Promise.all(
      ents.map(async (e) => {
        const fp = path.join(d, e.name);
        if (e.isDirectory()) stack.push(fp);
        else if (e.isFile()) {
          try { total += (await fs.promises.stat(fp)).size; } catch { /* ignore */ }
        }
      })
    );
  }
  return total;
}

function createWindow() {
  win = new BrowserWindow({
    width: 980,
    height: 760,
    minWidth: 820,
    minHeight: 620,
    backgroundColor: '#0b0d12',
    autoHideMenuBar: true,
    title: 'Nova APK Builder',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

ipcMain.handle('pick-zip', async () => {
  const r = await dialog.showOpenDialog(win, {
    filters: [{ name: 'Android project (ZIP)', extensions: ['zip'] }],
    properties: ['openFile'],
  });
  return r.canceled ? null : r.filePaths[0];
});

// فقط لینک‌های خودت اجازه باز شدن دارند
ipcMain.handle('open-external', (_e, url) => {
  if (/^https:\/\/(github\.com\/Nova2585nd|x\.com\/Nova_2585_nd|t\.me\/Nova_2585)$/.test(url)) {
    shell.openExternal(url);
  }
});

ipcMain.handle('copy-text', (_e, text) => {
  clipboard.writeText(String(text || ''));
  return true;
});

ipcMain.handle('get-data-root', () => dataRoot());

ipcMain.handle('pick-data-root', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled) return null;
  if (/[^\x00-\x7F]/.test(r.filePaths[0])) return { ok: false, errorKey: 'pathAscii' };
  const dir = path.join(r.filePaths[0], 'NovaAPKBuilderData');
  fs.mkdirSync(dir, { recursive: true });
  writeSettings({ ...readSettings(), dataRoot: dir });
  return { ok: true, dir };
});

ipcMain.handle('open-folder', () => shell.openPath(dataRoot()));

ipcMain.handle('get-sizes', async () => {
  const root = dataRoot();
  const t = path.join(root, 'toolchain');
  const parts = {
    jdk: [path.join(t, 'jdks'), path.join(t, 'jdk')],
    sdk: [path.join(t, 'android-sdk')],
    gradle: [path.join(t, 'gradle')],
    cache: [path.join(t, 'gradle-home')],
    work: [path.join(root, 'work')],
  };
  const out = { root, total: 0 };
  for (const [k, list] of Object.entries(parts)) {
    let s = 0;
    for (const p of list) s += await dirSize(p);
    out[k] = s;
    out.total += s;
  }
  return out;
});

// kind: 'cache' = کش Gradle + فایل‌های موقت | 'all' = همه ابزارها
ipcMain.handle('clear-data', async (_e, kind) => {
  if (building) return { ok: false, errorKey: 'busy' };
  const root = dataRoot();
  const t = path.join(root, 'toolchain');
  const targets = kind === 'cache' ? [path.join(t, 'gradle-home'), path.join(root, 'work')]
    : kind === 'all' ? [t, path.join(root, 'work')] : null;
  if (!targets) return { ok: false };
  try {
    for (const p of targets) {
      if (p !== root && p.startsWith(root)) await fs.promises.rm(p, { recursive: true, force: true, maxRetries: 3, retryDelay: 300 });
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
});

ipcMain.handle('show-item', (_e, p) => shell.showItemInFolder(p));

ipcMain.handle('start-build', async (_e, zipPath) => {
  if (building) return { ok: false, error: 'A build is already running' };
  building = true;
  const emit = (ch, data) => win.webContents.send(ch, data);
  try {
    const root = dataRoot();
    const apk = await builder.run(zipPath, {
      dataDir: path.join(root, 'toolchain'),
      workDir: path.join(root, 'work'),
      outDir: path.join(app.getPath('desktop'), 'Nova APK Output'),
      emit,
    });
    return { ok: true, apk };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  } finally {
    building = false;
  }
});
