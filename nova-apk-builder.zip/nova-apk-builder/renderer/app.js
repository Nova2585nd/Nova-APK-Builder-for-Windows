const $ = (s) => document.querySelector(s);

// ---------- translations (EN default, FA available) ----------
const T = {
  en: {
    subtitle: 'Drop in a zipped Android project, get an APK.',
    step1: 'Select project', step2: 'Prepare tools', step3: 'Build', step4: 'Get APK',
    aiHint: 'Writing your app with AI? Give it the rules this builder needs.',
    copyPrompt: 'Copy AI prompt', copied: 'Copied ✔',
    dropTitle: 'Drop your project .zip here', dropSub: 'or click to browse', dropChosen: 'Project selected ✔',
    start: 'Start build', building: 'Building ...',
    notice: 'Only build projects you trust: Gradle runs the project\u2019s build scripts on your PC.',
    detected: 'Detected:',
    okTitle: 'APK is ready ✔', showApk: 'Show in folder',
    failed: 'Build failed:', seeLog: '(details in the log below)', onlyZip: 'Only .zip files are accepted.',
    copyErr: 'Copy error for AI',
    details: 'Details (log)', storeLabel: 'Tools folder:', change: 'Change',
    storage: 'Storage', stRefresh: 'Refresh', stOpen: 'Open folder', stCache: 'Clear build cache', stAll: 'Delete all tools',
    sJdk: 'JDK', sSdk: 'Android SDK', sGradle: 'Gradle versions', sCache: 'Gradle cache (downloaded libraries)',
    sWork: 'Temporary project files', sTotal: 'Total', calculating: 'Calculating ...',
    confirmCache: 'Delete the Gradle cache and temporary files? They will be downloaded again when needed.',
    confirmAll: 'Delete ALL downloaded tools (JDK, Android SDK, Gradle)? The next build will download them again.',
    busy: 'A build is running. Try again when it finishes.',
    pathAscii: 'The path must contain English characters only (e.g. D:\\NovaAPK), because Gradle has trouble with non-ASCII paths.',
    langBtn: 'فارسی',
  },
  fa: {
    subtitle: 'زیپ پروژه را بده، APK تحویل بگیر.',
    step1: 'انتخاب پروژه', step2: 'آماده‌سازی ابزارها', step3: 'ساخت', step4: 'تحویل APK',
    aiHint: 'برنامه‌ات را با هوش مصنوعی می‌نویسی؟ قوانین لازم برای این برنامه را به او بده.',
    copyPrompt: 'کپی پرامپت هوش مصنوعی', copied: 'کپی شد ✔',
    dropTitle: 'فایل زیپ پروژه را اینجا بینداز', dropSub: 'یا کلیک کن تا انتخاب کنی', dropChosen: 'پروژه انتخاب شد ✔',
    start: 'شروع ساخت', building: 'در حال ساخت ...',
    notice: 'فقط پروژه‌های قابل‌اعتماد را بیلد کن: Gradle اسکریپت‌های پروژه را روی کامپیوتر تو اجرا می‌کند.',
    detected: 'تشخیص داده شد:',
    okTitle: 'APK آماده شد ✔', showApk: 'نمایش در پوشه',
    failed: 'ساخت ناموفق بود:', seeLog: '(جزئیات در لاگ پایین)', onlyZip: 'فقط فایل .zip قابل قبول است.',
    copyErr: 'کپی خطا برای هوش مصنوعی',
    details: 'جزئیات (لاگ)', storeLabel: 'محل ذخیره ابزارها:', change: 'تغییر',
    storage: 'فضای ذخیره‌سازی', stRefresh: 'بروزرسانی', stOpen: 'باز کردن پوشه', stCache: 'پاک کردن کش بیلد', stAll: 'حذف همه ابزارها',
    sJdk: 'JDK', sSdk: 'Android SDK', sGradle: 'نسخه‌های Gradle', sCache: 'کش Gradle (کتابخانه‌های دانلودشده)',
    sWork: 'فایل‌های موقت پروژه', sTotal: 'مجموع', calculating: 'در حال محاسبه ...',
    confirmCache: 'کش Gradle و فایل‌های موقت پاک شود؟ در صورت نیاز دوباره دانلود می‌شوند.',
    confirmAll: 'همه ابزارهای دانلودشده (JDK، Android SDK، Gradle) پاک شوند؟ بیلد بعدی دوباره دانلود می‌کند.',
    busy: 'یک بیلد در حال اجراست. بعد از پایان دوباره امتحان کن.',
    pathAscii: 'مسیر باید فقط حروف انگلیسی داشته باشد (مثلا D:\\NovaAPK)، چون Gradle با مسیر فارسی مشکل دارد.',
    langBtn: 'English',
  },
};

let lang = 'en';
try { lang = localStorage.getItem('lang') === 'fa' ? 'fa' : 'en'; } catch { /* ignore */ }
const t = (k) => (T[lang] && T[lang][k]) || T.en[k] || k;

// ---------- state ----------
let zip = null;
let building = false;
let err = null;        // { key } or { msg }
let info = null;       // detected versions
let logLines = [];
let sizes = null;

function fmt(n) {
  if (n < 1024) return n + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
  return n.toFixed(n >= 100 ? 0 : 1) + ' ' + u[i];
}

function flash(btn, key) {
  const old = btn.dataset.i18n;
  btn.dataset.i18n = key;
  btn.textContent = t(key);
  setTimeout(() => { btn.dataset.i18n = old; btn.textContent = t(old); }, 1600);
}

function renderErr() {
  const box = $('#resultErr');
  if (!err) { box.hidden = true; return; }
  box.hidden = false;
  $('#errText').textContent = err.key ? t(err.key) : `${t('failed')}\n${err.msg}\n\n${t('seeLog')}`;
  $('#copyErr').hidden = !!err.key;
}

function renderDetected() {
  const el = $('#detected');
  if (!info) { el.hidden = true; return; }
  el.hidden = false;
  el.textContent = `${t('detected')} AGP ${info.agp || '?'} · Gradle ${info.gradle} (${info.gradleSrc}) · JDK ${info.jdk} · compileSdk ${info.compileSdk || '?'}`;
}

function renderSizes() {
  const box = $('#srows');
  if (!sizes) { box.innerHTML = ''; const d = document.createElement('div'); d.className = 'srow'; d.textContent = t('calculating'); box.appendChild(d); return; }
  box.innerHTML = '';
  const rows = [['sJdk', sizes.jdk], ['sSdk', sizes.sdk], ['sGradle', sizes.gradle], ['sCache', sizes.cache], ['sWork', sizes.work], ['sTotal', sizes.total]];
  for (const [k, v] of rows) {
    const row = document.createElement('div');
    row.className = 'srow' + (k === 'sTotal' ? ' total' : '');
    const a = document.createElement('span'); a.textContent = t(k);
    const b = document.createElement('b'); b.textContent = fmt(v);
    row.append(a, b);
    box.appendChild(row);
  }
}

function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  $('#dropTitle').dataset.i18n = zip ? 'dropChosen' : 'dropTitle';
  $('#start').dataset.i18n = building ? 'building' : 'start';
  document.querySelectorAll('[data-i18n]').forEach((el) => (el.textContent = t(el.dataset.i18n)));
  $('#lang').textContent = t('langBtn');
  renderErr();
  renderDetected();
  if ($('#storage').open) renderSizes();
}

$('#lang').addEventListener('click', () => {
  lang = lang === 'en' ? 'fa' : 'en';
  try { localStorage.setItem('lang', lang); } catch { /* ignore */ }
  applyLang();
});

$('#logoImg').addEventListener('error', (e) => e.target.remove());

function setStep(id, state) {
  const el = document.querySelector(`[data-step="${id}"]`);
  if (el) el.dataset.state = state;
}

function setZip(p) {
  zip = p;
  const sub = $('#dropSub');
  sub.removeAttribute('data-i18n');
  sub.textContent = p.split(/[\\/]/).pop();
  $('#drop').classList.add('has-file');
  $('#start').disabled = false;
  $('#resultOk').hidden = true;
  err = null;
  info = null;
  setStep('pick', 'done');
  setStep('tools', 'active');
  ['build', 'deliver'].forEach((s) => setStep(s, 'idle'));
  applyLang();
}

// ---------- file picking ----------
const drop = $('#drop');
drop.addEventListener('click', async () => {
  if (building) return;
  const p = await api.pickZip();
  if (p) setZip(p);
});
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', (e) => {
  e.preventDefault();
  drop.classList.remove('over');
  if (building) return;
  const f = e.dataTransfer.files[0];
  if (f && f.name.toLowerCase().endsWith('.zip')) setZip(api.pathOf(f));
  else { err = { key: 'onlyZip' }; renderErr(); }
});

// ---------- AI prompts ----------
$('#copyPrompt').addEventListener('click', async () => {
  await api.copyText(PROMPTS.newProject);
  flash($('#copyPrompt'), 'copied');
});

$('#copyErr').addEventListener('click', async () => {
  const tail = logLines.slice(-150).map((l) => (l.length > 300 ? l.slice(0, 300) + ' ...' : l)).join('\n');
  const parts = [PROMPTS.errorIntro, ''];
  if (info) parts.push(`Detected by the builder: AGP ${info.agp || 'unknown'}, Gradle ${info.gradle} (${info.gradleSrc}), JDK ${info.jdk}, compileSdk ${info.compileSdk || 'unknown'}`);
  if (err && err.msg) parts.push(`Builder error: ${err.msg}`);
  parts.push('', 'Build log (last lines):', tail);
  await api.copyText(parts.join('\n'));
  flash($('#copyErr'), 'copied');
});

// ---------- build events ----------
api.onStep(({ id, state }) => setStep(id, state));
api.onLog((line) => {
  logLines.push(line);
  if (logLines.length > 5000) logLines = logLines.slice(-3000);
  const log = $('#log');
  log.textContent += line + '\n';
  log.scrollTop = log.scrollHeight;
});
api.onProgress(({ label, value }) => {
  const fill = $('#fill');
  $('#plabel').textContent = label || '';
  if (value === null) { fill.classList.add('indeterminate'); fill.style.width = ''; }
  else { fill.classList.remove('indeterminate'); fill.style.width = Math.round(value * 100) + '%'; }
});
api.onInfo((d) => { info = d; renderDetected(); });

$('#start').addEventListener('click', async () => {
  if (!zip || building) return;
  building = true;
  err = null;
  info = null;
  logLines = [];
  $('#start').disabled = true;
  $('#progressWrap').hidden = false;
  $('#resultOk').hidden = true;
  $('#log').textContent = '';
  applyLang();

  const r = await api.startBuild(zip);

  building = false;
  $('#start').disabled = false;
  $('#progressWrap').hidden = true;
  if (r.ok) {
    $('#apkPath').textContent = r.apk;
    $('#resultOk').hidden = false;
    $('#showApk').onclick = () => api.showItem(r.apk);
    api.showItem(r.apk);
  } else {
    err = { msg: r.error };
    $('.logbox').open = true;
  }
  applyLang();
  if ($('#storage').open) refreshSizes();
});

// ---------- tools folder + storage ----------
api.getDataRoot().then((p) => ($('#dataRoot').textContent = p));
$('#changeRoot').addEventListener('click', async () => {
  if (building) return;
  const r = await api.pickDataRoot();
  if (!r) return;
  if (r.ok) { $('#dataRoot').textContent = r.dir; err = null; if ($('#storage').open) refreshSizes(); }
  else err = { key: r.errorKey };
  renderErr();
});

async function refreshSizes() {
  sizes = null;
  renderSizes();
  sizes = await api.getSizes();
  renderSizes();
}
$('#storage').addEventListener('toggle', () => { if ($('#storage').open) refreshSizes(); });
$('#stRefresh').addEventListener('click', refreshSizes);
$('#stOpen').addEventListener('click', () => api.openFolder());

async function clearData(kind, confirmKey) {
  if (!confirm(t(confirmKey))) return;
  const r = await api.clearData(kind);
  if (!r.ok && r.errorKey) err = { key: r.errorKey };
  else if (!r.ok) err = { msg: r.error || 'Delete failed' };
  else err = null;
  renderErr();
  refreshSizes();
}
$('#stCache').addEventListener('click', () => clearData('cache', 'confirmCache'));
$('#stAll').addEventListener('click', () => clearData('all', 'confirmAll'));

// ---------- footer links ----------
document.querySelectorAll('.link').forEach((b) => b.addEventListener('click', () => api.openExternal(b.dataset.url)));

applyLang();
