// منطق اصلی: باز کردن زیپ -> تشخیص نسخه‌ها -> آماده‌سازی ابزار (فقط آنچه لازم است) -> بیلد با Gradle -> تحویل APK
const fs = require('fs');
const path = require('path');
const https = require('https');
const { spawn } = require('child_process');
const { detect, plan, chooseJdk, DEFAULT_GRADLE } = require('./detect');

const URLS = {
  jdk: (n) => `https://api.adoptium.net/v3/binary/latest/${n}/ga/windows/x64/jdk/hotspot/normal/eclipse`,
  gradle: (v) => `https://services.gradle.org/distributions/gradle-${v}-bin.zip`,
};
const CMDLINE_BASE = 'https://dl.google.com/android/repository/';
const CMDLINE_FALLBACK = [15859902, 13114758, 11076708];
// tar.exe خود ویندوز (نه tar گیت که زیپ را باز نمی‌کند)
const TAR = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');

// ---------- ابزارهای کمکی ----------
function download(url, dest, onProgress, hops = 0) {
  return new Promise((resolve, reject) => {
    if (hops > 8) return reject(new Error('Too many redirects'));
    https
      .get(url, { headers: { 'User-Agent': 'NovaAPKBuilder' } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          return resolve(download(new URL(res.headers.location, url).toString(), dest, onProgress, hops + 1));
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error(`Download failed (${res.statusCode}): ${url}`));
        }
        const total = Number(res.headers['content-length']) || 0;
        let got = 0;
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        const file = fs.createWriteStream(dest);
        res.on('data', (c) => {
          got += c.length;
          if (total && onProgress) onProgress(got / total);
        });
        res.pipe(file);
        file.on('finish', () => file.close(() => resolve(dest)));
        file.on('error', reject);
      })
      .on('error', reject);
  });
}

function fetchText(url, hops = 0) {
  return new Promise((resolve, reject) => {
    if (hops > 5) return reject(new Error('Too many redirects'));
    https
      .get(url, { headers: { 'User-Agent': 'NovaAPKBuilder' } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          return resolve(fetchText(new URL(res.headers.location, url).toString(), hops + 1));
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        let s = '';
        res.setEncoding('utf8');
        res.on('data', (c) => (s += c));
        res.on('end', () => resolve(s));
      })
      .on('error', reject);
  });
}

function exec(cmdline, { cwd, env, input } = {}, onLine = () => {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmdline, { cwd, env, shell: true, windowsHide: true });
    const handle = (d) => d.toString().split(/\r?\n/).forEach((l) => l.trim() && onLine(l));
    p.stdout.on('data', handle);
    p.stderr.on('data', handle);
    p.on('error', reject);
    p.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`Command failed (exit ${code})`))));
    p.stdin.on('error', () => {});
    if (input) p.stdin.write(input);
    p.stdin.end();
  });
}

async function unzip(zipFile, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  await exec(`"${TAR}" -xf "${zipFile}" -C "${destDir}"`);
}

function findDir(root, pred, maxDepth = 3) {
  const queue = [[root, 0]];
  while (queue.length) {
    const [dir, depth] = queue.shift();
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    if (pred(dir, entries)) return dir;
    if (depth < maxDepth) {
      for (const e of entries) if (e.isDirectory() && e.name !== 'build' && e.name !== '__MACOSX') queue.push([path.join(dir, e.name), depth + 1]);
    }
  }
  return null;
}

function findFiles(root, test, out = []) {
  let entries = [];
  try { entries = fs.readdirSync(root, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const p = path.join(root, e.name);
    if (e.isDirectory()) findFiles(p, test, out);
    else if (test(p)) out.push(p);
  }
  return out;
}

// متغیر PATH در ویندوز ممکن است «Path» نوشته شود؛ کلید واقعی را پیدا می‌کنیم
function makeEnv(javaHome, sdkRoot, extra = {}) {
  const env = { ...process.env };
  const pk = Object.keys(env).find((k) => k.toLowerCase() === 'path') || 'Path';
  env[pk] = `${path.join(javaHome, 'bin')};${env[pk] || ''}`;
  env.JAVA_HOME = javaHome;
  env.ANDROID_HOME = sdkRoot;
  env.ANDROID_SDK_ROOT = sdkRoot;
  return Object.assign(env, extra);
}

// ---------- JDK ----------
function findJavaHome(dataDir, n) {
  const roots = [path.join(dataDir, 'jdks', String(n))];
  if (n === 17) roots.push(path.join(dataDir, 'jdk')); // مسیر نسخه‌های قبلی برنامه
  for (const r of roots) {
    if (!fs.existsSync(r)) continue;
    const d = fs.readdirSync(r).map((x) => path.join(r, x)).find((p) => fs.existsSync(path.join(p, 'bin', 'java.exe')));
    if (d) return d;
  }
  return null;
}

async function ensureJdk(dataDir, n, emit) {
  let home = findJavaHome(dataDir, n);
  if (home) return home;
  emit('log', `Downloading JDK ${n} ...`);
  const z = await download(URLS.jdk(n), path.join(dataDir, '_downloads', `jdk${n}.zip`), (v) => emit('progress', { label: `JDK ${n}`, value: v }));
  emit('log', `Extracting JDK ${n} ...`);
  await unzip(z, path.join(dataDir, 'jdks', String(n)));
  fs.rmSync(z, { force: true });
  home = findJavaHome(dataDir, n);
  if (!home) throw new Error(`JDK ${n} installation failed`);
  return home;
}

// ---------- Android SDK ----------
async function cmdlineCandidates(log) {
  const found = new Set();
  try {
    const xml = await fetchText(CMDLINE_BASE + 'repository2-3.xml');
    for (const m of xml.matchAll(/commandlinetools-win-(\d+)_latest\.zip/g)) found.add(Number(m[1]));
  } catch (e) {
    log('Could not read the version list from Google, using the fallback list (' + e.message + ')');
  }
  const list = [...found].sort((a, b) => b - a);
  for (const n of CMDLINE_FALLBACK) if (!list.includes(n)) list.push(n);
  return list.map((n) => `${CMDLINE_BASE}commandlinetools-win-${n}_latest.zip`);
}

// sdkmanager جدید خودش JDK 17 می‌خواهد، پس همیشه با JDK 17 اجرا می‌شود
async function ensureSdk(dataDir, jdk17, compileSdk, emit) {
  const log = (m) => emit('log', m);
  const sdkRoot = path.join(dataDir, 'android-sdk');
  const sdkmanager = path.join(sdkRoot, 'cmdline-tools', 'latest', 'bin', 'sdkmanager.bat');
  const tmp = path.join(dataDir, '_downloads');

  if (!fs.existsSync(sdkmanager)) {
    log('Downloading Android command-line tools ...');
    let z = null;
    let lastErr = null;
    for (const u of await cmdlineCandidates(log)) {
      try {
        log('Downloading ' + u.split('/').pop());
        z = await download(u, path.join(tmp, 'cmdline.zip'), (v) => emit('progress', { label: 'Android Tools', value: v }));
        break;
      } catch (e) {
        lastErr = e;
        log('Failed: ' + e.message);
      }
    }
    if (!z) throw lastErr || new Error('Downloading Android command-line tools failed');
    const x = path.join(tmp, 'cmdline-x');
    fs.rmSync(x, { recursive: true, force: true });
    await unzip(z, x);
    fs.mkdirSync(path.join(sdkRoot, 'cmdline-tools'), { recursive: true });
    fs.renameSync(path.join(x, 'cmdline-tools'), path.join(sdkRoot, 'cmdline-tools', 'latest'));
    fs.rmSync(tmp, { recursive: true, force: true });
  }

  const env = makeEnv(jdk17, sdkRoot);
  const sm = (pkgs) => `"${sdkmanager}" --sdk_root="${sdkRoot}" ${pkgs.map((p) => `"${p}"`).join(' ')}`;

  const baseMissing = ['platform-tools', 'build-tools', 'platforms'].some((d) => !fs.existsSync(path.join(sdkRoot, d)));
  if (baseMissing) {
    log('Installing Android platform and build-tools (a few minutes, first run only) ...');
    emit('progress', { label: 'SDK', value: null });
    await exec(sm(['platform-tools', 'build-tools;34.0.0', 'platforms;android-34']), { env, input: 'y\n'.repeat(30) }, log);
  }
  if (compileSdk && !fs.existsSync(path.join(sdkRoot, 'platforms', `android-${compileSdk}`))) {
    log(`Installing Android platform ${compileSdk} (required by the project) ...`);
    emit('progress', { label: 'SDK', value: null });
    try {
      await exec(sm([`platforms;android-${compileSdk}`]), { env, input: 'y\n'.repeat(30) }, log);
    } catch (e) {
      log(`Could not install platform ${compileSdk} (${e.message}); Gradle may try to download it itself.`);
    }
  }
  await exec(`"${sdkmanager}" --sdk_root="${sdkRoot}" --licenses`, { env, input: 'y\n'.repeat(60) }, () => {});
  emit('progress', { label: '', value: 1 });
  return sdkRoot;
}

// ---------- Gradle (فقط وقتی پروژه wrapper کامل ندارد) ----------
async function ensureGradle(dataDir, v, emit) {
  const root = path.join(dataDir, 'gradle');
  const bat = path.join(root, `gradle-${v}`, 'bin', 'gradle.bat');
  if (fs.existsSync(bat)) return bat;
  emit('log', `Downloading Gradle ${v} ...`);
  const z = await download(URLS.gradle(v), path.join(dataDir, `_gradle-${v}.zip`), (p) => emit('progress', { label: `Gradle ${v}`, value: p }));
  await unzip(z, root);
  fs.rmSync(z, { force: true });
  if (!fs.existsSync(bat)) throw new Error(`Gradle ${v} installation failed`);
  return bat;
}

// ---------- جریان اصلی ----------
async function run(zipPath, { dataDir, workDir, outDir, emit }) {
  if (process.platform !== 'win32') throw new Error('This app only runs on Windows');
  const log = (m) => emit('log', m);
  const step = (id, state) => emit('step', { id, state });

  let current = 'tools';
  try {
    step('tools', 'active');

    // 1) باز کردن پروژه و تشخیص نسخه‌ها
    fs.rmSync(workDir, { recursive: true, force: true });
    log('Extracting the zip file ...');
    await unzip(zipPath, workDir);
    const projectDir = findDir(workDir, (_d, es) => es.some((e) => /^settings\.gradle(\.kts)?$/.test(e.name)));
    if (!projectDir) throw new Error('Android project not found (no settings.gradle in the zip)');
    log('Project found: ' + path.basename(projectDir));

    const info = detect(projectDir);
    let p = plan(info);
    log(`Detected: AGP ${info.agp || 'unknown'}, Gradle ${p.gradle} (${p.gradleSrc}), JDK ${p.jdk}, compileSdk ${info.compileSdk || 'unknown'}, wrapper ${p.useWrapper ? 'complete' : 'missing or incomplete'}`);

    // 2) ابزارهای لازم
    const jdk17 = await ensureJdk(dataDir, 17, emit);
    let javaHome = p.jdk === 17 ? jdk17 : await ensureJdk(dataDir, p.jdk, emit);
    const sdkRoot = await ensureSdk(dataDir, jdk17, info.compileSdk, emit);

    let gradleCmd;
    if (p.useWrapper) {
      gradleCmd = path.join(projectDir, 'gradlew.bat');
    } else {
      try {
        gradleCmd = await ensureGradle(dataDir, p.gradle, emit);
      } catch (e) {
        if (p.gradle === DEFAULT_GRADLE) throw e;
        log(`Gradle ${p.gradle} is not available (${e.message}); falling back to ${DEFAULT_GRADLE}.`);
        p = { ...p, gradle: DEFAULT_GRADLE, gradleSrc: 'fallback', jdk: chooseJdk(info.agp, DEFAULT_GRADLE, info.javaWanted) };
        javaHome = await ensureJdk(dataDir, p.jdk, emit);
        gradleCmd = await ensureGradle(dataDir, p.gradle, emit);
      }
    }
    emit('info', { agp: info.agp, gradle: p.gradle, gradleSrc: p.gradleSrc, jdk: p.jdk, compileSdk: info.compileSdk });
    step('tools', 'done');

    // 3) بیلد
    current = 'build';
    step('build', 'active');
    fs.writeFileSync(path.join(projectDir, 'local.properties'), `sdk.dir=${sdkRoot.replace(/\\/g, '/')}\n`);
    const env = makeEnv(javaHome, sdkRoot, { GRADLE_USER_HOME: path.join(dataDir, 'gradle-home') });
    emit('progress', { label: 'Build', value: null });
    // -Dorg.gradle.java.home مسیر JDK احتمالی داخل gradle.properties پروژه را نادیده می‌گیرد
    await exec(
      `"${gradleCmd}" assembleDebug --no-daemon --console=plain "-Dorg.gradle.java.home=${javaHome.replace(/\\/g, '/')}"`,
      { cwd: projectDir, env },
      log
    );

    // 4) تحویل
    current = 'deliver';
    step('build', 'done');
    step('deliver', 'active');
    const apks = findFiles(projectDir, (f) => f.endsWith('.apk') && f.includes(path.join('build', 'outputs', 'apk')));
    if (!apks.length) throw new Error('Build finished but no APK was found');
    const apk = apks.find((f) => /debug/i.test(f)) || apks[0];
    fs.mkdirSync(outDir, { recursive: true });
    const dest = path.join(outDir, path.basename(zipPath, path.extname(zipPath)) + '-debug.apk');
    fs.copyFileSync(apk, dest);
    emit('progress', { label: '', value: 1 });
    step('deliver', 'done');
    return dest;
  } catch (err) {
    step(current, 'error');
    throw err;
  }
}

module.exports = { run };
