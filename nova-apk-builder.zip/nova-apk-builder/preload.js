const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  pickZip: () => ipcRenderer.invoke('pick-zip'),
  pathOf: (file) => webUtils.getPathForFile(file),
  getDataRoot: () => ipcRenderer.invoke('get-data-root'),
  pickDataRoot: () => ipcRenderer.invoke('pick-data-root'),
  openFolder: () => ipcRenderer.invoke('open-folder'),
  getSizes: () => ipcRenderer.invoke('get-sizes'),
  clearData: (kind) => ipcRenderer.invoke('clear-data', kind),
  copyText: (text) => ipcRenderer.invoke('copy-text', text),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  showItem: (p) => ipcRenderer.invoke('show-item', p),
  startBuild: (p) => ipcRenderer.invoke('start-build', p),
  onStep: (cb) => ipcRenderer.on('step', (_e, d) => cb(d)),
  onLog: (cb) => ipcRenderer.on('log', (_e, d) => cb(d)),
  onProgress: (cb) => ipcRenderer.on('progress', (_e, d) => cb(d)),
  onInfo: (cb) => ipcRenderer.on('info', (_e, d) => cb(d)),
});
