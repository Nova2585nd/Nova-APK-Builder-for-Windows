# Nova APK Builder

Drop in a zipped Android project, get an installable APK. No Android Studio, no manual JDK/SDK setup.
UI languages: English (default) and Persian, switch with the button in the header.

## What's new in 1.1
- **Auto-detection** of the Android Gradle Plugin, Gradle and JDK version from the project itself
  (build files, version catalog, wrapper properties). Missing `gradle-wrapper.jar` is handled automatically.
  JDK 11 / 17 / 21 are downloaded only when a project needs them.
- **Copy error for AI** button: copies the error log plus a ready prompt for ChatGPT / Claude.
- **Copy AI prompt** button on the first screen: rules that make an AI generate a project this builder can compile.
- **Storage manager**: see how much space the tools use, clear the Gradle cache, or delete all tools.
- Choose where tools are stored (e.g. another drive) with "Change". Use an English-only path.

## Build the .exe (on Windows)
1. Install Node.js LTS (only needed to build the app itself, not for end users).
2. In the project folder:
   - `npm install`
   - `npm start`      # test run
   - `npm run dist`   # output: dist\Nova APK Builder 1.1.0.exe (portable)

## Logo
Put your logo as `logo.png` inside `assets/`. Until then an empty box is shown.

## Notes
- First run downloads tools automatically (roughly 1-2 GB, estimate), once.
- Output: `Nova APK Output` folder on the Desktop. Build type: debug APK (no keystore needed).
- Native Android Gradle projects only (Kotlin/Java). Flutter, React Native, Unity etc. are not supported.
- Only build projects you trust: Gradle runs the project's build scripts on your PC.
